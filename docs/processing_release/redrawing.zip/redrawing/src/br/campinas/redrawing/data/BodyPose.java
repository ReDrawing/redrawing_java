package br.campinas.redrawing.data;

import java.util.Map;

public class BodyPose{
	public float time;
	public Map<String,float[]> keypoints;
	public boolean pixel_space;
	public String user_id;
	public String[] keypoints_names;
	public String frame_id;
}
