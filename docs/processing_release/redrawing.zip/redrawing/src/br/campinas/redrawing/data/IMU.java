package br.campinas.redrawing.data;

import java.util.Map;

public class IMU{
	public float time;
	public String frame_id;
	public float[] accel;
	public float[] gyro;
	public float[] mag;
}
