package br.campinas.redrawing.data;

import java.util.Map;

public class Image{
	public int time;
	public String frame_id;
	public int[][][] image;
}
