package br.campinas.redrawing.data;

import java.util.Map;

public class Frame_TF{
	public int time;
	public float[][] R;
	public float[] t;
	public String frame_origin;
	public String frame_destity;
}
