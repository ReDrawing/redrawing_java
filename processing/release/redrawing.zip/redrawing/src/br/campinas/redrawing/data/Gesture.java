package br.campinas.redrawing.data;

import java.util.Map;

public class Gesture{
	public int time;
	public String gesture;
}
