package br.campinas.redrawing.data;

import java.util.Map;

public class ObjectDetection{
	public int time;
	public float[][] bounding_box;
	public String frame_id;
}
