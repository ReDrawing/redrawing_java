package br.campinas.redrawing.data;

import java.util.Map;

public class Orientation{
	public int time;
	public String frame_id;
	public float[] orientation;
}
